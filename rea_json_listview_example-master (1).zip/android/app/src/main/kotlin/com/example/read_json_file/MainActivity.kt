package com.example.read_json_file

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
